using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExcelAsset]
public class Item_01 : ScriptableObject
{
	public List<ReadExcel> Sheet1; 

}
