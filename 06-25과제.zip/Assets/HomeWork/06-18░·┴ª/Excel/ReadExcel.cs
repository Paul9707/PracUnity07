using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ReadExcel
{
    public int ID;
    public string Name;
    public int price;
    public string itemType;
    public string description;

}
