using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UITest : MonoBehaviour
{
    public Transform normalObjectTaransform;
    public RectTransform rectTransform;

    private void Start()
    {
        
    }
}
